import express from 'express';
import { createServer as createViteServer } from 'vite';
import { createApiRouter } from './src/server/apiRouter';

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10mb' }));
app.use('/api', createApiRouter());

// ---------------- VITE MIDDLEWARE / STATIC SERVING ----------------

async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const path = await import('path');
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer();
